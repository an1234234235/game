# Colony Pilot

Colony Pilot is an offline RimWorld 1.6 mod. Its first iteration automatically assigns colonist work priorities based on relevant skills, while keeping disabled work types disabled. Firefighting and patient care receive the highest priority.

This is a foundation, not yet a full autonomous player: it does not place construction orders, manage bills or research, or make strategic decisions about quests and threats.

## Settings

Enable or disable automatic work-priority balancing in the mod settings. When enabled, priorities are recalculated approximately once per in-game hour. Disabling it stops further automatic changes; it does not restore priorities that were assigned earlier.

## Build

Build `Source/ColonyPilot/ColonyPilot.csproj` with MSBuild and the .NET Framework 4.7.2 targeting pack installed. By default, the project looks for RimWorld's `RimWorldWin64_Data/Managed` directory under the Steam library in `Program Files (x86)`. If RimWorld is installed elsewhere, pass its Managed directory as the `RimWorldManagedPath` MSBuild property.

The resulting `Assemblies/ColonyPilot.dll` and this mod folder should be placed in RimWorld's `Mods` directory.
