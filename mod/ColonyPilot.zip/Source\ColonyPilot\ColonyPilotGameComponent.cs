using RimWorld;
using Verse;

namespace ColonyPilot
{
    public sealed class ColonyPilotGameComponent : GameComponent
    {
        private const int UpdateIntervalTicks = 2500;
        private int nextUpdateTick;

        public ColonyPilotGameComponent(Game game)
        {
        }

        public override void GameComponentTick()
        {
            if (Find.TickManager.TicksGame < nextUpdateTick)
            {
                return;
            }

            nextUpdateTick = Find.TickManager.TicksGame + UpdateIntervalTicks;
            if (ColonyPilotMod.Settings == null || !ColonyPilotMod.Settings.manageWorkPriorities)
            {
                return;
            }

            foreach (Map map in Find.Maps)
            {
                foreach (Pawn pawn in map.mapPawns.FreeColonists)
                {
                    BalanceWorkPriorities(pawn);
                }
            }
        }

        private static void BalanceWorkPriorities(Pawn pawn)
        {
            if (pawn.workSettings == null || pawn.skills == null)
            {
                return;
            }

            foreach (WorkTypeDef workType in DefDatabase<WorkTypeDef>.AllDefsListForReading)
            {
                if (pawn.WorkTypeIsDisabled(workType))
                {
                    continue;
                }

                int priority;
                if (workType.defName == "Firefighter" || workType.defName == "Patient")
                {
                    priority = 1;
                }
                else
                {
                    float skill = pawn.skills.AverageOfRelevantSkillsFor(workType);
                    priority = skill >= 15f ? 1 :
                        skill >= 10f ? 2 :
                        skill >= 5f ? 3 : 4;
                }

                pawn.workSettings.SetPriority(workType, priority);
            }
        }
    }
}
