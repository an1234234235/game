using UnityEngine;
using Verse;

namespace ColonyPilot
{
    public sealed class ColonyPilotSettings : ModSettings
    {
        public bool manageWorkPriorities = true;

        public override void ExposeData()
        {
            Scribe_Values.Look(ref manageWorkPriorities, "manageWorkPriorities", true);
        }
    }

    public sealed class ColonyPilotMod : Mod
    {
        public static ColonyPilotSettings Settings { get; private set; }

        public ColonyPilotMod(ModContentPack content) : base(content)
        {
            Settings = GetSettings<ColonyPilotSettings>();
        }

        public override string SettingsCategory()
        {
            return "ColonyPilot.SettingsCategory".Translate();
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            var listing = new Listing_Standard();
            listing.Begin(inRect);
            listing.CheckboxLabeled(
                "ColonyPilot.ManageWorkPriorities".Translate(),
                ref Settings.manageWorkPriorities);
            listing.Gap();
            listing.Label("ColonyPilot.SettingsHelp".Translate());
            listing.End();
        }
    }
}
